import SwiftUI


struct ContentView: View {
    @State private var currentIndex = 0
    @Environment(\.colorScheme) var colorScheme
    @State private var navigate = false

    var body: some View {
        NavigationView {
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(fruitsData.indices, id: \.self) { index in
                        let fruit = fruitsData[index]
                        let bgColor = colorScheme == .dark ? fruit.gradientColors[1] : fruit.gradientColors[0]

                        ZStack {
                            bgColor
                                .edgesIgnoringSafeArea(.all)
                                .cornerRadius(30)
                                .padding()
                                .shadow(radius: 10)
                                

                            VStack(spacing: 20) {
                                Image(fruit.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 250)

                                Text(fruit.title)
                                    .font(.title)
                                    .bold()
                                    .foregroundColor(.white)

                                Text(fruit.headline)
                                    .font(.body)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal)
                                    .foregroundColor(.white.opacity(0.9))
                                
                                NavigationLink(destination: FruitListView(), isActive: $navigate) {
                                    Button("Start") {
                                        navigate = true
                                    }
                                    .padding()
                                    .foregroundColor(.white)
                                    .background(Color.white .opacity(0.3))
                                    .cornerRadius(10)
                                    .shadow(radius: 5)
                                }
                                .padding(.top, 20)

                            }
                            .padding()
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .frame(height: 650)

                            }
            .padding()
        }
    }
}
    


#Preview {
    ContentView()
}
