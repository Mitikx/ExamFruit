import SwiftUI

@main
struct ProjetFruitsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
