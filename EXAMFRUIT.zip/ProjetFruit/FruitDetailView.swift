import SwiftUI

struct FruitDetailView: View {
    var fruit: Fruit
    @Environment(\.colorScheme) var colorScheme
    @State private var showNutrition = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                ZStack {
                    LinearGradient(
                        gradient: Gradient(colors: fruit.gradientColors),
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                    .frame(height: 300)
                    .cornerRadius(20)
                    .shadow(radius: 5)

                    Image(fruit.image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 180)
                        .shadow(radius: 10)
                }
                .padding(.horizontal)

                Text(fruit.title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(fruit.gradientColors.last)

                Text(fruit.headline)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                    .padding(.horizontal)
                
                VStack(alignment: .leading, spacing: 12) {
                        HStack {
                        Text("Valeurs nutritionnelles")
                            .foregroundColor(fruit.gradientColors.last)
                            .font(.title2)
                            .fontWeight(.semibold)

                        Spacer()

                        Button(action: {
                            withAnimation {
                                showNutrition.toggle()
                            }
                        }) {
                            Image(systemName: showNutrition ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                                .foregroundColor(fruit.gradientColors.first ?? .green)
                                .font(.title2)
                        }
                    }

                    if showNutrition {
                        ForEach(fruit.nutrition, id: \.self) { item in
                            HStack {
                                Image(systemName: "leaf.circle.fill")
                                    .foregroundColor(fruit.gradientColors.first ?? .green)
                                Text(item)
                            }
                            .transition(.opacity.combined(with: .move(edge: .top)))
                        }
                    }
                }
                .padding()

                VStack(alignment: .leading, spacing: 8) {
                    Text("En savoir plus sur : \(fruit.title)")
                        .foregroundColor(fruit.gradientColors.last)
                        .font(.title2)
                        .fontWeight(.semibold)

                    Text(fruit.description)
                        .font(.body)
                        .multilineTextAlignment(.leading)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding()
            }
            .navigationBarTitle(fruit.title, displayMode: .inline)
        }
    }
}



struct FruitDetailView_Previews: PreviewProvider {
    static var previews: some View {
        FruitDetailView(fruit: Fruit(
            title: "Myrtille",
            headline: "Les myrtilles sont des fruits sucrés, nutritifs et extrêmement populaires dans le monde entier.",
            image: "blueberry",
            gradientColors: [Color("ColorBlueberryLight"), Color("ColorBlueberryDark")],
            description: """
              Les myrtilles sont des plantes à fleurs vivaces produisant des baies bleues ou violettes. Elles sont classées dans la section Cyanococcus du genre Vaccinium. Le genre Vaccinium comprend également les canneberges, les airelles, les myrtilles sauvages (bilberries) et les myrtilles de Madère.

              Les myrtilles commercialisées — à la fois sauvages (lowbush) et cultivées (highbush) — sont toutes originaires d’Amérique du Nord. Les variétés highbush ont été introduites en Europe dans les années 1930.

              Les myrtilles sont généralement des arbrisseaux rampants dont la taille varie de 10 centimètres à 4 mètres de hauteur. Dans la production commerciale, les espèces à petites baies de la taille d’un pois poussant sur des buissons bas sont appelées « myrtilles lowbush » (synonyme de « sauvages »), tandis que les espèces à baies plus grosses poussant sur des buissons cultivés plus hauts sont appelées « myrtilles highbush ».

              Le Canada est le principal producteur de myrtilles lowbush, tandis que les États-Unis produisent environ 40 % de l’approvisionnement mondial en myrtilles highbush.

              UTILISATIONS

              Les myrtilles sont vendues fraîches ou transformées en fruits surgelés individuellement (IQF), en purée, en jus, en baies séchées ou infusées. Elles peuvent ensuite être utilisées dans divers produits de consommation tels que les gelées, les confitures, les tartes aux myrtilles, les muffins, les collations ou comme ingrédient dans les céréales pour le petit-déjeuner.

              La confiture de myrtilles est préparée à partir de myrtilles, de sucre, d’eau et de pectine de fruit. La sauce aux myrtilles est une sauce sucrée dont l’ingrédient principal est la myrtille.

              Le vin de myrtille est élaboré à partir de la pulpe et de la peau du fruit, qui sont fermentées puis maturées ; la variété lowbush est généralement utilisée.

              NUTRIMENTS

              Les myrtilles sont composées de 14 % de glucides, 0,7 % de protéines, 0,3 % de lipides et 84 % d’eau (tableau). Elles contiennent des quantités négligeables de micronutriments, avec des apports modérés (par rapport aux valeurs quotidiennes recommandées) en manganèse, vitamine C, vitamine K et fibres alimentaires (tableau).

              De manière générale, la teneur en nutriments des myrtilles représente un faible pourcentage des apports journaliers recommandés (tableau). Une portion apporte environ 57 kcal avec une charge glycémique de 6.
              """,
            nutrition: ["240 kJ (57 kcal)","9,96 g","0,33 g","0,74 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Sodium, Zinc"]
          )
        )
    }
}
