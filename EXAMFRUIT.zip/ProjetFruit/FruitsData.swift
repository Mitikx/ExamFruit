import SwiftUI

let fruitsData: [Fruit] = [
    Fruit(
        title: "Myrtille",
        headline: "Les myrtilles sont des fruits sucrés, nutritifs et extrêmement populaires dans le monde entier.",
        image: "blueberry",
        gradientColors: [Color("ColorBlueberryLight"), Color("ColorBlueberryDark")],
        description: """
Les myrtilles sont des plantes à fleurs vivaces produisant des baies bleues ou violettes. Elles appartiennent au genre Vaccinium.

Les myrtilles commercialisées — sauvages (lowbush) ou cultivées (highbush) — sont originaires d’Amérique du Nord. Les variétés highbush ont été introduites en Europe dans les années 1930.

UTILISATIONS

Les myrtilles sont consommées fraîches ou transformées en fruits surgelés, jus, purées ou baies séchées. Elles sont utilisées dans les confitures, tartes, muffins et céréales.

NUTRIMENTS

Elles contiennent 14 % de glucides, 0,7 % de protéines, 0,3 % de lipides et 84 % d’eau. Une portion apporte environ 57 kcal.
""",
        nutrition: ["240 kJ (57 kcal)","9,96 g","0,33 g","0,74 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Sodium, Zinc"]
    ),

    Fruit(
        title: "Fraise",
        headline: "Appréciée pour son arôme caractéristique, sa couleur rouge vif, sa texture juteuse et sa douceur.",
        image: "strawberry",
        gradientColors: [Color("ColorStrawberryLight"), Color("ColorStrawberryDark")],
        description: """
La fraise de jardin est largement cultivée dans le monde pour son fruit parfumé, rouge vif et sucré.

UTILISATION CULINAIRE

Elle se consomme fraîche, en confiture, en jus, dans les desserts, glaces et produits laitiers.

NUTRITION

100 g de fraises apportent environ 33 kcal et constituent une excellente source de vitamine C.
""",
        nutrition: ["136 kJ (33 kcal)","4,89 g","0,3 g","0,67 g","B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Citron",
        headline: "Délicieux et rafraîchissant, le citron est riche en vitamine C.",
        image: "lemon",
        gradientColors: [Color("ColorLemonLight"), Color("ColorLemonDark")],
        description: """
Le citron (Citrus limon) est un agrume originaire d’Asie du Sud.

Il est utilisé pour son jus acide en cuisine, pâtisserie et boissons.

NUTRITION

Le citron est une excellente source de vitamine C.
""",
        nutrition: ["121 kJ (29 kcal)","2,5 g","0,3 g","1,1 g","B1, B2, B3, B5, B6, B9, C","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Zinc"]
    ),

    Fruit(
        title: "Prune",
        headline: "Fruit très nutritif, riche en vitamines, minéraux et antioxydants.",
        image: "plum",
        gradientColors: [Color("ColorPlumLight"), Color("ColorPlumDark")],
        description: """
La prune est un fruit à noyau sucré ou légèrement acidulé.

Elle peut être consommée fraîche, séchée (pruneau) ou transformée en confiture et jus.
""",
        nutrition: ["192 kJ (46 kcal)","9,92 g","0,28 g","0,7 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Citron vert",
        headline: "Agrume vert, acide et riche en vitamine C.",
        image: "lime",
        gradientColors: [Color("ColorLimeLight"), Color("ColorLimeDark")],
        description: """
Le citron vert est utilisé en cuisine pour son jus et son zeste parfumé.

Il est courant dans les cuisines mexicaine, thaïlandaise et indienne.
""",
        nutrition: ["126 kJ (30 kcal)","1,7 g","0,2 g","0,7 g","B1, B2, B3, B5, B6, B9, C","Calcium, Fer, Magnésium, Phosphore, Potassium, Sodium"]
    ),

    Fruit(
        title: "Grenade",
        headline: "Fruit sucré apprécié depuis l’Antiquité.",
        image: "pomegranate",
        gradientColors: [Color("ColorPomegranateLight"), Color("ColorPomegranateDark")],
        description: """
La grenade est un fruit rouge contenant de nombreuses graines juteuses appelées arilles.

Elle est utilisée en jus, en cuisine et en pâtisserie.
""",
        nutrition: ["346 kJ (83 kcal)","13,67 g","1,17 g","1,67 g","B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Poire",
        headline: "Fruit sucré en forme de cloche, apprécié depuis l’Antiquité.",
        image: "pear",
        gradientColors: [Color("ColorPearLight"), Color("ColorPearDark")],
        description: """
La poire est un fruit juteux pouvant être consommé frais, en jus ou séché.

Il existe plus de 3000 variétés cultivées dans le monde.
""",
        nutrition: ["239 kJ (57 kcal)","9,75 g","0,14 g","0,36 g","B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Groseille",
        headline: "Petit fruit acidulé utilisé en dessert et confiture.",
        image: "gooseberry",
        gradientColors: [Color("ColorGooseberryLight"), Color("ColorGooseberryDark")],
        description: """
La groseille est un petit fruit originaire d’Europe.

Elle est utilisée en confitures, desserts et boissons.
""",
        nutrition: ["184 kJ (44 kcal)","6,15 g","0,58 g","0,88 g","A, B1, B2, B3, B5, B6, B9, C, E","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Mangue",
        headline: "Fruit tropical sucré et juteux.",
        image: "mango",
        gradientColors: [Color("ColorMangoLight"), Color("ColorMangoDark")],
        description: """
La mangue est un fruit tropical originaire d’Asie du Sud.

Elle est consommée fraîche, en jus ou dans de nombreux desserts.
""",
        nutrition: ["250 kJ (60 kcal)","13,7 g","0,38 g","0,82 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Pastèque",
        headline: "Fruit rafraîchissant et très hydratant.",
        image: "watermelon",
        gradientColors: [Color("ColorWatermelonLight"), Color("ColorWatermelonDark")],
        description: """
La pastèque est un fruit riche en eau, idéal en été.

Sa chair rouge est sucrée et très rafraîchissante.
""",
        nutrition: ["127 kJ (30 kcal)","6,2 g","0,15 g","0,61 g","A, B1, B2, B3, B5, B6, C","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Cerise",
        headline: "Petit fruit rouge sucré ou acidulé.",
        image: "cherry",
        gradientColors: [Color("ColorCherryLight"), Color("ColorCherryDark")],
        description: """
La cerise est un fruit à noyau apprécié frais ou en dessert.

Elle est utilisée en pâtisserie, confitures et jus.
""",
        nutrition: ["209 kJ (50 kcal)","8,5 g","0,3 g","1 g","A, B1, B2, B3, B5, B6, B9, C, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    ),

    Fruit(
        title: "Pamplemousse",
        headline: "Agrume légèrement amer et riche en vitamine C.",
        image: "grapefruit",
        gradientColors: [Color("ColorGrapefruitLight"), Color("ColorGrapefruitDark")],
        description: """
Le pamplemousse est un agrume à chair blanche, rose ou rouge.

Il est souvent consommé frais ou en jus.
""",
        nutrition: ["138 kJ (33 kcal)","7,31 g","0,10 g","0,8 g","B1, B2, B3, B5, B6, B9, C, E","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Zinc"]
    ),

    Fruit(
        title: "Pomme",
        headline: "L’un des fruits les plus populaires et excellents pour la santé.",
        image: "apple",
        gradientColors: [Color("ColorAppleLight"), Color("ColorAppleDark")],
        description: """
La pomme est cultivée dans le monde entier.

Elle se consomme fraîche, en jus, en compote ou en pâtisserie.
""",
        nutrition: ["218 kJ (52 kcal)","10,39 g","0,17 g","0,26 g","A, B1, B2, B3, B5, B6, B9, C, E, K","Calcium, Fer, Magnésium, Manganèse, Phosphore, Potassium, Sodium, Zinc"]
    )
]
