import SwiftUI

struct FruitListView: View {
    @State private var showSettings = false

    var body: some View {
        NavigationView {
            List(fruitsData) { fruit in
                NavigationLink(destination: FruitDetailView(fruit: fruit)) {
                    HStack {
                        Image(fruit.image)
                            .resizable()
                            .frame(width: 50, height: 50)
                            .cornerRadius(8)

                        VStack(alignment: .leading) {
                            Text(fruit.title)
                                .font(.headline)
                            Text(fruit.headline)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(2)
                        }
                    }
                    .padding(.vertical, 4)
                }
            }
            .navigationTitle("Fruits")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        showSettings.toggle()
                    }) {
                        Image(systemName: "line.horizontal.3")
                            .imageScale(.large)
                    }
                }
            }
            .sheet(isPresented: $showSettings) {
                SettingsView()
            }
        }
    }
}


#Preview {
    FruitListView()
}

