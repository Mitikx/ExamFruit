import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    SettingsBox(
                        title: "App Info",
                        icon: "info.circle",
                        content: {
                            HStack(alignment: .center, spacing: 12) {
                                Image("watchicon")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .cornerRadius(8)
                                Text("La plupart des fruits sont naturellement pauvres en matières grasses, en sodium et en calories. Aucun ne contient de cholestérol. Les fruits sont des sources de nombreux nutriments essentiels, notamment le potassium, les fibres alimentaires, les vitamines et bien plus encore.")
                                    .font(.body)
                            }
                            .padding(.top, 4)
                        }
                    )

                    SettingsBox(
                        title: "Apparence",
                        icon: "paintbrush",
                        content: {
                            VStack(alignment: .leading, spacing: 12) {
                                Text("Si vous le souhaitez, vous pouvez redémarrer l’application en appuyant sur le bouton dans cette boîte. De cette façon, le processus d’intégration (onboarding) recommencera et vous verrez à nouveau l’écran de bienvenue.")
                                Toggle(isOn: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Is On@*/.constant(true)/*@END_MENU_TOKEN@*/) {
                                    Label("Redemarrer l'application", systemImage:"arrow.clockwise.circle.fill")
                                }
                            }
                            .padding(.top, 4)
                        }
                    )
                    
                    SettingsBox(
                        title: "Application",
                        icon: "iphone",
                        content: {
                            VStack(alignment: .leading, spacing: 8) {
                                SettingsRow(label: "Developer", value: "Tristan")
                                SettingsRow(label: "Designer", value: "Tristan")
                                SettingsRow(label: "Compatibility", value: "iOS 16+")
                                SettingsRow(label: "Website", value: "SwiftUI Masterclass")
                            }
                            .padding(.top, 4)
                        }
                    )
                }
                .padding()
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}


#Preview {
    SettingsView()
}
